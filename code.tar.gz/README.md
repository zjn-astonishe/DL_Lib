# DL_Lib
Some function for deep learning
